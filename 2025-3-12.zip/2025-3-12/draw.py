import numpy as np
import matplotlib.pyplot as plt

x_values = np.arange(0, 20, 0.5)


def draw(x):
    result = 1 - x * np.exp(-x) - np.exp(-x)
    return result


y = []

for x in x_values:
    y.append(draw(x))

plt.plot(x_values, y, 'b-', marker='o')
plt.xlim(0, 20)
plt.ylim(0, 1.5)
plt.xlabel('Time')
plt.ylabel('response')
plt.title('X(s)')
plt.grid(True)
plt.show()
