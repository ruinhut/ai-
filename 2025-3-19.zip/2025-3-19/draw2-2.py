import numpy as np
import matplotlib.pyplot as plt

x_values = np.arange(0, 10, 0.05)


def draw_0(x):
    result = x - np.sin(4 * x) / 4
    return result


def draw_3(x):
    result = x - 3 / 16 + (8 / np.sqrt(55)) * np.exp(- 1.5 * x) * np.sin(x * np.sqrt(55) / 2 + 2 * np.arctan(np.sqrt(55) / 3)) / 4
    return result


def draw_4(x):
    result = x - np.sqrt(2) / 4 + np.sqrt(2) * np.exp(- 2 * np.sqrt(2) * x) * np.sin(x * np.sqrt(8) + 2 * np.arctan(1)) / 4
    return result


def draw_8(x):
    result = x + np.exp(-4 * x) / 2 + x * np.exp(-4 * x) - 0.5
    return result


def draw_10(x):
    result = x + (2 * np.exp(-2 * x) / 3) - (np.exp(-8 * x) / 24) - 5 / 8
    return result


y_0 = []
y_3 = []
y_4 = []
y_8 = []
y_10 = []

for x in x_values:
    y_0.append(draw_0(x))
    y_3.append(draw_3(x))
    y_4.append(draw_4(x))
    y_8.append(draw_8(x))
    y_10.append(draw_10(x))

print(draw_4(0))
plt.plot(x_values, y_0, 'b-', marker=' ', color='b', label='a=0')
plt.plot(x_values, y_3, 'b-', marker=' ', color='r', label='a=3')
plt.plot(x_values, y_4, 'b-', marker=' ', color='y', label='a=4sqrt(2)')
plt.plot(x_values, y_8, 'b-', marker=' ', color='green', label='a=8')
plt.plot(x_values, y_10, 'b-', marker=' ', color='orange', label='a=10')
plt.xlim(0, 10)
plt.ylim(0, 10)
plt.xlabel('Time')
plt.ylabel('response')
plt.title('C(t)')
plt.grid(True)
plt.legend()
plt.show()
