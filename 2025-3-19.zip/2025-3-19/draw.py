import numpy as np
import matplotlib.pyplot as plt

x_values = np.arange(0, 10, 0.2)


def draw(x):
    result = 1 - np.exp(-x) * np.sin(x * np.sqrt(15) + np.arctan(np.sqrt(15)))
    return result


y = []

for x in x_values:
    y.append(draw(x))

plt.plot(x_values, y, 'b-', marker='o')
plt.xlim(0, 10)
plt.ylim(0, 2)
plt.xlabel('Time')
plt.ylabel('response')
plt.title('C(t)')
plt.grid(True)
plt.show()
